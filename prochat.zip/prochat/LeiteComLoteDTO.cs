﻿namespace MilkApi
{
    public class LeiteComLoteDTO
    {
        public int ID_Gado { get; set; }
        public DateTime Data { get; set; }
        public decimal Litros { get; set; }
        public int Num { get; set; }
        public int ID_Usuario { get; set; } 
    }

}
