namespace MilkApi
{
    public class Leite
    {
        public int Id { get; set; }
        public int ID_Gado { get; set; }
        public DateTime Data {get; set; }
        public decimal Litros { get; set; }


    }
}
